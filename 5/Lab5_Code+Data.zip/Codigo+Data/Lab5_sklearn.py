#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 14 16:12:41 2022
Modified on Mon Mar 13 2023

@author: CHANGE THE NAME

This script carries out a classification experiment of the spambase dataset by
means of the kNN classifier, USING THE SCIKIT-LEARN PACKAGE
"""

# Import whatever else you need to import
import pandas as pd
import os


# 
# -------------
# MAIN PROGRAM
# -------------
if __name__ == "__main__":


    # Load csv with data into a pandas dataframe
    """
    Each row in this dataframe contains a feature vector, which represents an
    email.
    Each column represents a variable, EXCEPT LAST COLUMN, which represents
    the true class of the corresponding element (i.e. row): 1 means "spam",
    and 0 means "not spam"
    """
    dir_data = "Data"
    spam_df = pd.read_csv(os.path.join(dir_data, "spambase_data.csv"))
    y_df = spam_df[['Class']].copy()
    X_df = spam_df.copy()
    X_df = X_df.drop('Class', axis=1)

    # Convert dataframe to numpy array
    X = X_df.to_numpy()
    y = y_df.to_numpy()
    
    """
    Parameter that indicates the proportion of elements that the test set will
    have
    """
    proportion_test = 0.3

    """
    Partition of the dataset into training and test sets is done. 
    Use the function train_test_split from scikit_learn
    """
    # ====================== YOUR CODE HERE ======================
    
    # ============================================================

    """
    Create an instance of the kNN classifier using scikit-learn
    """
    # ====================== YOUR CODE HERE ======================
    
    # ============================================================

    """
    Train the classifier
    """
    # ====================== YOUR CODE HERE ======================
    
    # ============================================================

    """
    Get the predictions for the test set samples given by the classifier
    """
    # ====================== YOUR CODE HERE ======================
    
    # ============================================================
    
    """
    Show the confusion matrix. Use the same methods that were used in the
    first part of the lab (i.e., see Lab5.py)
    """
    # ====================== YOUR CODE HERE ======================
    
    # ============================================================
